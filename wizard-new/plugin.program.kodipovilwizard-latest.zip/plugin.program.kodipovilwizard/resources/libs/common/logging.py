################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc
import xbmcgui
import xbmcvfs

import os
import re
import time

import _strptime

from resources.libs.common import tools
from resources.libs.common.config import CONFIG

# Python 3 only. The previous try/except wrapper here used to
# probe `urllib.request.FancyURLopener` (Py3) with a fallback to
# `urllib.FancyURLopener` (Py2). Python 3.14 REMOVED FancyURLopener
# from urllib.request entirely (deprecated since 3.6), which made
# the try branch raise ImportError, and the except branch then
# raises again on `from urllib import urlencode` (a Py2-only
# name that has never existed in Py3). Net effect: the whole
# wizard refused to start on Arch Linux + Python 3.14. We don't
# need either FancyURLopener or the Py2 fallback any more --
# `requests` is already a wizard dependency and handles the
# `post_log` HTTP POST much more cleanly. See post_log() below.
from urllib.parse import urlencode


URL = 'https://paste.ubuntu.com/'
EXPIRATION = 2592000
# What a log must not carry to paste.kodi.tv (public, and nothing there can be deleted). Since 0.5.21 a press
# sends the last run's log as well. Review, Nov 2026: this build's logs hold debrid and YouTube stream addresses
# (a token in each; YouTube's carry the viewer's own address), add-on keys in queries, IP addresses, the
# computer's name and the user's name in its home folder -- seen in a QA log that was posted by mistake.
# What a crash is read from (the player's lines, the codecs, the add-ons' own lines) stays as it is.
_SECRET_FIELDS = ('token|access_token|refresh_token|apikey|api_key|key|client_id|client_secret|sig|signature|'
                  'lsig|ip|password|pass')
REPLACES = (('//.+?:.+?@', '//USER:PASSWORD@'), ('<user>.+?</user>', '<user>USER</user>'), ('<pass>.+?</pass>',
                                                                                            '<pass>PASSWORD</pass>'),
            # a stream's address on a debrid service or on YouTube: its host stays, the rest is the viewer's
            (r'(https?://[^/\s"\'<>]*(?:real-debrid|premiumize|alldebrid|debrid-link|torbox|tb-cdn|googlevideo)'
             r'[^/\s"\'<>]*)/[^\s"\'<>]*', r'\1/REDACTED'),
            # the YouTube add-on's own stream address (its query is the stream's, the viewer's address in it)
            (r'(/youtube/stream\?)[^\s"\'<>]+', r'\1REDACTED'),
            # token=..., &key=..., ?ip=... in any address (the whole value, %2B and all) ...
            (r'(?i)([?&;](?:%s)=)[^&\s"\'<>]+' % _SECRET_FIELDS, r'\1REDACTED'),
            # ... and the same written inside another address (%3F / %26 / %3D, as Kodi logs a plugin:// path):
            # up to the next encoded field
            (r'(?i)((?:%%3F|%%26)(?:%s)%%3D)(?:(?!%%26)[^&\s"\'<>])+' % _SECRET_FIELDS, r'\1REDACTED'),
            # a bearer token (a stream's headers, an Authorization line)
            (r'(?i)(bearer(?:%20|\s+))[A-Za-z0-9._~+/=-]+', r'\1REDACTED'),
            # "token": "...", 'api_key': '...' (a dict or JSON in a line)
            (r'(?i)(["\'](?:%s)["\']\s*:\s*["\'])[^"\']+' % _SECRET_FIELDS, r'\1REDACTED'),
            # e-mail addresses
            (r'[\w.+-]+@[\w-]+(?:\.[\w-]+)+', 'EMAIL'),
            # IPv4, all but this device's own loopback and "any"
            (r'\b(?!127\.0\.0\.1\b)(?!0\.0\.0\.0\b)(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b',
             'x.x.x.x'),
            # the user's name in a home folder (Windows, macOS, Linux)
            (r'([A-Za-z]:[\\/]+Users[\\/]+|/Users/|/home/)[^\\/\s"\':]+', r'\1USER'),
            # the computer's name
            (r'(Local hostname: )\S+', r'\1HOST'),
            # the YouTube add-on's visitor id (it names this device to YouTube)
            (r"(Visitor:\s*)'[^']*'", r"\1'REDACTED'"))


def log(msg, level=xbmc.LOGINFO):
    # Always route to Kodi's native log (kodi.log) so the wizard is observable,
    # regardless of its own DEBUGLEVEL setting. The previous version did an
    # early `return False` when DEBUGLEVEL == '0', which swallowed EVERYTHING --
    # even LOGINFO/LOGWARNING/LOGERROR -- and was the "logging black hole".
    try:
        title = getattr(CONFIG, 'ADDONTITLE', 'Kodi POV IL Wizard')
        xbmc.log('{0}: {1}'.format(title, msg), level)
    except Exception:
        try:
            xbmc.log('Kodi POV IL Wizard: {0}'.format(msg), xbmc.LOGINFO)
        except Exception:
            pass

    # Optional wizard-owned logfile -- fully guarded so a logging failure can
    # never break a caller (e.g. the provisioning watchdog thread).
    try:
        # PatchEngine can report dozens of patches during startup. Kodi's native
        # log above already contains every one, so avoid repeating synchronous
        # appends to the Wizard logfile for this high-volume source. On some
        # Android profiles those appends stall the entire startup path.
        if str(msg).startswith('[PatchEngine]'):
            return
        if getattr(CONFIG, 'DEBUGLEVEL', '0') == '0' or getattr(CONFIG, 'ENABLEWIZLOG', 'false') != 'true':
            return

        # CRITICAL FIX (from older branch): On a FRESH install, the addon_data folder
        # might not exist yet. Ensure the directory exists before touching the log file.
        folder = os.path.dirname(CONFIG.WIZLOG)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)

        if not os.path.exists(CONFIG.WIZLOG):
            with open(CONFIG.WIZLOG, 'w+') as f:
                pass  # Context manager automatically handles closing

        lastcheck = getattr(CONFIG, 'NEXTCLEANDATE', 0)
        if lastcheck == 0:
            lastcheck = tools.get_date()

        if getattr(CONFIG, 'CLEANWIZLOG', 'false') == 'true' and time.mktime(time.strptime(lastcheck, "%Y-%m-%d %H:%M:%S")) <= tools.get_date():
            check_log()

        line = "[{0}] {1}".format(tools.get_date(formatted=True), msg)
        line = line.rstrip('\r\n') + '\n'
        tools.write_to_file(CONFIG.WIZLOG, line, mode='a')

    except Exception as log_err:
        try:
            xbmc.log('Kodi POV IL Wizard: could not write the wizard log: {0}'.format(log_err), xbmc.LOGWARNING)
        except Exception:
            pass


def check_log():
    next = tools.get_date(days=1, formatted=True)
    lines = tools.read_from_file(CONFIG.WIZLOG, errors='replace').split('\n')

    if CONFIG.CLEANWIZLOGBY == '0':  # By Days
        keep = tools.get_date(days=-CONFIG.MAXWIZDATES[int(float(CONFIG.CLEANDAYS))])
        x = 0
        for line in lines:
            if str(line[1:11]) >= str(keep):
                break
            x += 1
        newfile = lines[x:]
        tools.write_to_file(CONFIG.WIZLOG, '\n'.join(newfile))
    elif CONFIG.CLEANWIZLOGBY == '1':  # By Size
        maxsize = CONFIG.MAXWIZSIZE[int(float(CONFIG.CLEANSIZE))]*1024
        if os.path.getsize(CONFIG.WIZLOG) >= maxsize:
            start = int(len(lines)/2)
            newfile = lines[start:]
            tools.write_to_file(CONFIG.WIZLOG, '\n'.join(newfile))
    elif CONFIG.CLEANWIZLOGBY == '2':  # By Lines
        maxlines = CONFIG.MAXWIZLINES[int(float(CONFIG.CLEANLINES))]
        if len(lines) > maxlines:
            start = len(lines) - int(maxlines/2)
            newfile = lines[start:]
            tools.write_to_file(CONFIG.WIZLOG, '\n'.join(newfile))
    CONFIG.set_setting('nextwizcleandate', next)


def log_notify(title, message, times=2000, icon=CONFIG.ADDON_ICON, sound=False):
    dialog = xbmcgui.Dialog()
    dialog.notification(title, message, icon, int(times), sound)


def grab_log(file=False, old=False, wizard=False):
    if wizard:
        if os.path.exists(CONFIG.WIZLOG):
            return CONFIG.WIZLOG if file else tools.read_from_file(CONFIG.WIZLOG, errors='replace')
        else:
            return False
                
    logsfound = []

    if not os.path.isdir(CONFIG.LOGPATH):
        return False
    for item in [file for file in os.listdir(CONFIG.LOGPATH) if os.path.basename(file).startswith('kodi')]:
        if item.endswith('.log'):
            if (old and 'old' in item) or (not old and 'old' not in item):
                logsfound.append(os.path.join(CONFIG.LOGPATH, item))

    if len(logsfound) > 0:
        logsfound.sort(key=lambda f: os.path.getmtime(f))
        if file:
            return logsfound[-1]
        else:
            return tools.read_from_file(logsfound[-1], errors='replace')
    else:
        return False


# Kodi moves the last run's log to kodi.old.log when it starts again: after a crash that is the log that says
# why, and a viewer sends "the log" once Kodi is open again -- the one that does not (the owner's LG, Nov 2026:
# two uploads of the new run before the crash was found in the old one). It travels with kodi.log, in the same
# document and the same link, each cut to its last part (where its trouble is).
PREVIOUS_HEADER = '\n\n===== kodi.old.log: the run before this one (a crash shows at its end) =====\n\n'
CURRENT_ROOM, PREVIOUS_ROOM = 280000, 300000


def with_previous(content, previous):
    """kodi.log's text, then kodi.old.log's: one document. Kodi's settings noise is taken out of each first."""
    if not previous:
        return content
    content, said = _drop_settings_noise(content)
    previous, said_before = _drop_settings_noise(previous)
    content = said + content[-(CURRENT_ROOM - len(said)):]
    previous = said_before + previous[-(PREVIOUS_ROOM - len(said_before)):]
    return content + PREVIOUS_HEADER + previous


def upload_log():
    try:
        from resources.libs import fentastic_widgets
        fentastic_widgets.diagnostics()
    except Exception:
        pass
    files = get_files()
    previous = grab_log(file=True, old=True)
    for item in files:
        filetype = item[0]
        if filetype == 'oldlog':
            continue                # (it travels with kodi.log: with_previous)
        # (the viewer's language: the build's Hebrew)
        if filetype == 'log':
            name = os.path.basename(item[1]) or "kodi.log"
        elif filetype == 'oldlog':
            name = os.path.basename(item[1]) or "kodi.old.log"
        elif filetype == 'wizlog':
            name = "wizard.log"
        elif filetype == 'crashlog':
            name = "crash log"
        error = "\u05e9\u05dc\u05d9\u05d7\u05ea {0} \u05e0\u05db\u05e9\u05dc\u05d4".format(name)
        succes, data = read_log(item[1])
        if succes:
            content = clean_log(data)
            if filetype == 'log' and previous and os.path.isfile(previous):
                found, before = read_log(previous)
                if found:
                    content = with_previous(content, clean_log(before))
                    name = '{0} + {1}'.format(name, os.path.basename(previous))
            succes, result = post_log(content, name)
            if succes:
                # "The log was sent ({name}). Send this address, or a photo of the code, with what went wrong:"
                msg = ("\u05d4\u05dc\u05d5\u05d2 \u05e0\u05e9\u05dc\u05d7 ([COLOR {0}]{1}[/COLOR]). "
                       "\u05e9\u05dc\u05d7\u05d5 \u05d0\u05ea \u05d4\u05e7\u05d9\u05e9\u05d5\u05e8 "
                       "\u05d0\u05d5 \u05e6\u05dc\u05de\u05d5 \u05d0\u05ea \u05d4\u05e7\u05d5\u05d3, "
                       "\u05e2\u05dd \u05ea\u05d9\u05d0\u05d5\u05e8 \u05d4\u05d1\u05e2\u05d9\u05d4:"
                       "[CR][COLOR {2}]{3}[/COLOR]").format(CONFIG.COLOR1, name, CONFIG.COLOR1, result)

                # if len(self.email) > 5:
                # em_result, em_msg = self.email_Log(self.email, result, name)
                # if em_result == 'message':
                # msg += "[CR]%s" % em_msg
                # else:
                # msg += "[CR]Email ERROR: %s" % em_msg

                show_result(msg, result)
            else:
                show_result('{0}[CR]{1}'.format(error, result))
        else:
            show_result('{0}[CR]{1}'.format(error, data))


def get_files():
    logfiles = []
    kodilog = grab_log(file=True)
    old = grab_log(file=True, old=True)
    wizard = False if not os.path.exists(CONFIG.WIZLOG) else CONFIG.WIZLOG
    if kodilog:
        if os.path.exists(kodilog):
            logfiles.append(['log', kodilog])
        else:
            show_result("No log file found")
    else:
        show_result("No log file found")
    if CONFIG.KEEPOLDLOG:
        if old:
            if os.path.exists(old):
                logfiles.append(['oldlog', old])
            else:
                show_result("No old log file found")
        else:
            show_result("No old log file found")
    if CONFIG.KEEPWIZLOG:
        if wizard:
            logfiles.append(['wizlog', wizard])
        else:
            show_result("No wizard log file found")
    if CONFIG.KEEPCRASHLOG:
        crashlog_path = ''
        items = []
        if xbmc.getCondVisibility('system.platform.osx'):
            crashlog_path = os.path.join(os.path.expanduser('~'), 'Library/Logs/DiagnosticReports/')
            filematch = 'Kodi'
        elif xbmc.getCondVisibility('system.platform.ios'):
            crashlog_path = '/var/mobile/Library/Logs/CrashReporter/'
            filematch = 'Kodi'
        elif tools.platform() == 'linux':
            # not 100% accurate (crashlogs can be created in the dir kodi was started from as well)
            crashlog_path = os.path.expanduser('~')
            filematch = 'kodi_crashlog'
        elif tools.platform() == 'windows':
            log("Windows crashlogs are not supported, please disable this option in the addon settings")
        elif tools.platform() == 'android':
            log("Android crashlogs are not supported, please disable this option in the addon settings")
        if crashlog_path and os.path.isdir(crashlog_path):
            dirs, files = xbmcvfs.listdir(crashlog_path)
            for item in files:
                if filematch in item and os.path.isfile(os.path.join(crashlog_path, item)):
                    items.append(os.path.join(crashlog_path, item))
                    items.sort(key=lambda f: os.path.getmtime(f))
                    lastcrash = items[-1]
                    logfiles.append(['crashlog', lastcrash])
        if len(items) == 0:
            log("No crashlog file found")
    return logfiles


def read_log(path):
    lf = None
    try:
        lf = xbmcvfs.File(path)
        # Bytes, decoded leniently: File.read() decodes strictly, and one byte
        # that is not UTF-8 made the upload fail ("Unable to Read File").
        content = bytes(lf.readBytes()).decode('utf-8', 'replace')
        if content:
            return True, content
        else:
            log('file is empty')
            return False, "File is Empty"
    except Exception as e:
        log('unable to read file: {0}'.format(e))
        return False, "Unable to Read File"
    finally:
        if lf is not None:
            try:
                lf.close()
            except Exception:
                pass


def clean_log(content):
    for pattern, repl in REPLACES:
        content = re.sub(pattern, repl, content)
    return content


def show_result(message, url=None):
    """Display an uploaded link locally, with a text fallback for QR failures."""
    imagefile = None
    if url:
        try:
            import tempfile
            import segno
            from resources.libs.gui import window

            folder = os.path.join(CONFIG.PLUGIN_DATA, 'qrcodes')
            os.makedirs(folder, exist_ok=True)
            fd, imagefile = tempfile.mkstemp(prefix='log-', suffix='.png', dir=folder)
            os.close(fd)
            segno.make_qr(url).save(imagefile, scale=8)
            window.show_qr_code('loguploader.xml', imagefile, message)
            return
        except Exception as e:
            log('Could not display log QR: {0}'.format(e), level=xbmc.LOGWARNING)
        finally:
            if imagefile:
                try:
                    os.remove(imagefile)
                except OSError:
                    pass
    xbmcgui.Dialog().ok(CONFIG.ADDONTITLE, message)


_SETTINGS_NOISE = ('<CSettingsManager>: requested setting (', ') was not found')


def _drop_settings_noise(data):
    """Kodi's debug "requested setting (x) was not found" lines, taken out.

    With debug logging on, Kodi writes one for every stale key in an add-on's
    settings file each time the file is loaded. A field log (24 Oct 2026)
    was ~5,500 such lines in its last second -- the 600 KB we keep held
    nothing else, and the problem it was meant to show was cut off.

    Returns (text, header): header names how many lines and which keys were
    taken out, '' when none were."""
    try:
        if not isinstance(data, str) or _SETTINGS_NOISE[0] not in data:
            return data, ''
        kept, dropped, keys = [], 0, []
        for line in data.split('\n'):
            if _SETTINGS_NOISE[0] in line and _SETTINGS_NOISE[1] in line:
                dropped += 1
                key = line.split(_SETTINGS_NOISE[0], 1)[1].split(_SETTINGS_NOISE[1], 1)[0]
                if key not in keys:
                    keys.append(key)
            else:
                kept.append(line)
        names = ', '.join(keys)
        if len(names) > 3000:
            names = names[:3000] + ', ...'
        header = ('[Kodi POV IL Wizard] {0} debug lines "requested setting (...) was '
                  'not found" removed from this log ({1} keys: {2})\n'.format(
                      dropped, len(keys), names))
        return '\n'.join(kept), header
    except Exception:
        return data, ''


def post_log(data, name):
    """Upload the given log contents and return (success, url_or_error_msg).

    paste.ubuntu.com stopped accepting anonymous automated posts (the old
    code returned 'pov:error' / 'failed to connect'), so we now try a chain
    of reliable paste services and use the first that works:
      1. paste.kodi.tv  -- the official Kodi log paste (Hastebin API)
      2. 0x0.st         -- plain file upload, returns a bare URL
      3. dpaste.com     -- simple form API
    The requests library is already a wizard dependency."""
    try:
        import requests
    except ImportError as e:
        msg = 'requests module unavailable: {0}'.format(e)
        log(msg, level=xbmc.LOGERROR)
        return False, msg

    data, header = _drop_settings_noise(data)

    # Keep the most-recent ~600 KB: Hastebin caps document size, and the tail
    # of the log is where the actual error is. Logs only grow at the end. The
    # header goes on AFTER the cut, so a long log still says what was removed.
    try:
        if isinstance(data, str):
            room = 600000 - len(header)
            if len(data) > room:
                data = data[-room:]
            data = header + data
    except Exception:
        pass

    headers = {
        'User-Agent': '{0}: {1}'.format(
            CONFIG.ADDON_ID, CONFIG.ADDON_VERSION),
    }
    payload = data.encode('utf-8', 'replace') if isinstance(data, str) else data

    # 1) paste.kodi.tv (Hastebin) -- the canonical place for Kodi logs.
    try:
        r = requests.post('https://paste.kodi.tv/documents',
                          data=payload, headers=headers, timeout=30)
        if r.status_code == 200:
            key = (r.json() or {}).get('key')
            if key:
                url = 'https://paste.kodi.tv/{0}'.format(key)
                log("URL for {0}: {1}".format(name, url))
                return True, url
        log('paste.kodi.tv returned {0}'.format(r.status_code),
            level=xbmc.LOGWARNING)
    except Exception as e:
        log('paste.kodi.tv failed: {0}'.format(e), level=xbmc.LOGWARNING)

    # 2) 0x0.st -- multipart file upload, replies with a bare URL.
    try:
        files = {'file': (name or 'kodi.log', payload, 'text/plain')}
        r = requests.post('https://0x0.st', files=files,
                          headers=headers, timeout=30)
        body = (r.text or '').strip()
        if r.status_code == 200 and body.startswith('http'):
            log("URL for {0}: {1}".format(name, body))
            return True, body
        log('0x0.st returned {0}'.format(r.status_code), level=xbmc.LOGWARNING)
    except Exception as e:
        log('0x0.st failed: {0}'.format(e), level=xbmc.LOGWARNING)

    # 3) dpaste.com -- simple form API, returns the paste URL as plain text.
    try:
        r = requests.post('https://dpaste.com/api/v2/',
                          data={'content': data, 'syntax': 'text',
                                'expiry_days': 7},
                          headers=headers, timeout=30)
        body = (r.text or '').strip()
        if r.status_code in (200, 201) and body.startswith('http'):
            log("URL for {0}: {1}".format(name, body))
            return True, body
        log('dpaste returned {0}'.format(r.status_code), level=xbmc.LOGWARNING)
    except Exception as e:
        log('dpaste failed: {0}'.format(e), level=xbmc.LOGWARNING)

    return False, 'all paste services failed (check the internet connection)'


# CURRENTLY NOT IN USE
def copy_to_clipboard(txt):
    import subprocess

    platform = tools.platform()
    if platform == 'windows':
        try:
            cmd = 'echo ' + txt.strip() + '|clip'
            return subprocess.check_call(cmd, shell=True)
            pass
        except:
            pass
    elif platform == 'linux':
        try:
            from subprocess import Popen, PIPE

            p = Popen(['xsel', '-pi'], stdin=PIPE)
            p.communicate(input=txt)
        except:
            pass
    else:
        pass


# CURRENTLY NOT IN USE
# def email_log(email, results, file):
    # URL = 'http://aftermathwizard.net/mail_logs.php'
    # data = {'email': email, 'results': results, 'file': file, 'wizard': CONFIG.ADDONTITLE}
    # params = urlencode(data)

    # try:
        # result = LogURLopener().open(URL, params)
        # returninfo = result.read()
        # log(str(returninfo))
    # except Exception as e:
        # a = 'failed to connect to the server'
        # log("{0}: {1}".format(a, str(e)), level=xbmc.LOGERROR)
        # return False, a

    # try:
        # return True, "Emailing logs is currently disabled."
        # # js_data = json.loads(returninfo)

        # # if 'type' in js_data:
            # # return js_data['type'], str(js_data['text'])
        # # else:
            # # return str(js_data)
    # except Exception as e:
        # log("ERROR: {0}".format(str(e)), level=xbmc.LOGERROR)
        # return False, "Error Sending Email."


# LogURLopener class removed -- post_log() now uses requests.post()
# instead of the deprecated urllib.request.FancyURLopener (which
# Python 3.14 removed entirely). The class had no other callers.


def view_log_file():
    from resources.libs.gui import window

    mainlog = grab_log(file=True)
    oldlog = grab_log(file=True, old=True)
    wizlog = grab_log(file=True, wizard=True)
    
    choices = []
    logfiles = {'mainlog': "View {0}".format(os.path.basename(mainlog)), 'oldlog': "View {0}".format(os.path.basename(oldlog)), 'wizlog': "View {0}".format(os.path.basename(wizlog))}
    
    which = 0
    logtype = oldlog
    msg = grab_log(old=True)
    
    if mainlog:
        choices.append(logfiles['mainlog'])
    if oldlog:
        choices.append(logfiles['oldlog'])
    if wizlog:
        choices.append(logfiles['wizlog'])

    dialog = xbmcgui.Dialog()

    if len(choices) > 0:
        which = dialog.select(CONFIG.ADDONTITLE, choices)
        if which == -1:
            log_notify('[COLOR {0}]View Log[/COLOR]'.format(CONFIG.COLOR1),
                       '[COLOR {0}]View Log Cancelled![/COLOR]'.format(CONFIG.COLOR2))
            return
        elif which == 0:
            logtype = mainlog
        elif which == 1:
            logtype = oldlog
        elif which == 2:
            logtype = wizlog
    elif len(choices) == 0:
        log_notify('[COLOR {0}]View Log[/COLOR]'.format(CONFIG.COLOR1),
                   '[COLOR {0}]No Log File Found![/COLOR]'.format(CONFIG.COLOR2))
        return
    else:
        if mainlog:
            logtype = mainlog
        elif oldlog:
            logtype = oldlog
        elif wizlog:
            logtype = wizlog

    window.show_log_viewer("Viewing Log File", log_file=logtype, ext_buttons=True)


def swap_debug():
    import threading

    new = '"debug.showloginfo"'
    query = '{{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{{"setting":{0}}}, "id":1}}'.format(new)
    response = xbmc.executeJSONRPC(query)
    log("Debug Logging Get Settings: {0}".format(str(response)))
    if 'false' in response:
        value = 'true'
        threading.Thread(target=_dialog_watch).start()
        xbmc.sleep(200)
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(
            new, value)
        response = xbmc.executeJSONRPC(query)
        log_notify(CONFIG.ADDONTITLE,
                           '[COLOR {0}]Debug Logging:[/COLOR] [COLOR {1}]Enabled[/COLOR]'.format(CONFIG.COLOR1,
                                                                                                   CONFIG.COLOR2))
        log("Debug Logging Set Settings: {0}".format(str(response)))
    elif 'true' in response:
        value = 'false'
        threading.Thread(target=_dialog_watch).start()
        xbmc.sleep(200)
        query = '{{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{{"setting":{0},"value":{1}}}, "id":1}}'.format(
            new, value)
        response = xbmc.executeJSONRPC(query)
        log_notify(CONFIG.ADDONTITLE,
                   '[COLOR {0}]Debug Logging:[/COLOR] [COLOR {1}]Disabled[/COLOR]'.format(CONFIG.COLOR1,
                                                                                         CONFIG.COLOR2))
        log("Debug Logging Set Settings: {0}".format(str(response)))


def _dialog_watch():
    x = 0
    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        xbmc.sleep(100)

    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(yesnodialog, 11)')
        return True
    else:
        return False


def error_list(file):
    errors = []
    b = tools.read_from_file(file, errors='replace').replace('\n', '[CR]').replace('\r', '')

    match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(b)
    for item in match:
        errors.append(item)
    return errors


def error_checking(log=None, count=None, last=None):
    errors = []
    error1 = []
    error2 = []
    if log is None:
        curr = grab_log(file=True)
        old = grab_log(file=True, old=True)
        if not old  and not curr:
            if count is None:
                log_notify('[COLOR {0}]View Error Log[/COLOR]'.format(CONFIG.COLOR1),
                           '[COLOR {0}]No Log File Found![/COLOR]'.format(CONFIG.COLOR2))
                return
            else:
                return 0
        if curr:
            error1 = error_list(curr)
        if old:
            error2 = error_list(old)
        if len(error2) > 0:
            for item in error2:
                errors = [item] + errors
        if len(error1) > 0:
            for item in error1:
                errors = [item] + errors
    else:
        error1 = error_list(log)
        if len(error1) > 0:
            for item in error1:
                errors = [item] + errors

    if count is not None:
        return len(errors)
    elif len(errors) > 0:
        from resources.libs.gui import window
        
        if last is None:
            i = 0
            string = ''
            for item in errors:
                i += 1
                string += "[B][COLOR red]ERROR NUMBER {0}:[/B][/COLOR] {1}\n".format(str(i), item.replace(CONFIG.HOME, '/').replace('                                        ', ''))
            window.show_log_viewer("Viewing Errors in Log", string)
        else:
            string = "[B][COLOR red]Last Error in Log:[/B][/COLOR] {0}\n".format(errors[0].replace(CONFIG.HOME, '/').replace('                                        ', ''))
            window.show_log_viewer("Viewing Last Error in Log", string)

    else:
        log_notify('[COLOR {0}]View Error Log[/COLOR]'.format(CONFIG.COLOR1),
                   '[COLOR {0}]No Errors Found![/COLOR]'.format(CONFIG.COLOR2))

