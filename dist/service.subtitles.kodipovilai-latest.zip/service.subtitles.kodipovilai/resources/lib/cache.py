# MoranSubs by MoranTheKing - https://github.com/MoranTheKing/Kodi-POV-IL
# SPDX-License-Identifier: GPL-3.0-or-later (additional terms: LICENSE.txt)
# Persistent translation cache. Stored under
# userdata/addon_data/<id>/cache/. Files are named by deterministic
# hash of (imdb_id, season, episode, source_lang) so the same item
# always lands on the same path; existence + age check on lookup.
#
# Eviction policy:
#  - TTL: any file not accessed for cache_ttl_days days is removed
#  - Size cap: if cache exceeds cache_size_mb, oldest-access first
#    until back to 80% of cap
# The daemon in service.py runs this once per Kodi start + every
# 24h.

import os
import hashlib
import time
import json

from . import kodi_utils

CACHE_SUBDIR_TRANSLATED = 'translated'
CACHE_SUBDIR_SOURCE     = 'source'
CACHE_SUBDIR_METADATA   = 'metadata'


def _ensure_subdir(name):
    p = os.path.join(kodi_utils.cache_dir(), name)
    if not os.path.isdir(p):
        try:
            os.makedirs(p)
        except OSError:
            pass
    return p


def _key(imdb_id, season, episode, source_lang, source_id=None):
    """Stable filename for one cached translation.

    source_id (Wyzie URL or sha1 of source SRT content) is ALWAYS
    mixed into the digest when provided. Before v0.2.48 it was only
    mixed in when imdb_id was missing, which meant two different
    source SRTs for the same movie/episode collided on one cache
    slot -- clicking subtitle B after caching A would serve A's
    translation as if it were B's.
    """
    parts = [str(imdb_id or 'unknown'),
             str(season or '0'),
             str(episode or '0'),
             str(source_lang or 'en'),
             str(source_id or '')]
    digest = hashlib.sha1('|'.join(parts).encode('utf-8')).hexdigest()[:16]
    return '{0}_S{1}E{2}_{3}_{4}'.format(parts[0], parts[1], parts[2], parts[3], digest)


def translated_path(imdb_id, season, episode, source_lang,
                    source_id=None, tier=''):
    # `tier` namespaces a higher-quality variant in its OWN cache file without
    # colliding with the plain one (currently 'ar' = Arabic-gender-boosted).
    suffix = ('.' + tier) if tier else ''
    return os.path.join(
        _ensure_subdir(CACHE_SUBDIR_TRANSLATED),
        _key(imdb_id, season, episode, source_lang, source_id) +
        suffix + '.he.srt')


def source_path(imdb_id, season, episode, source_lang,
                source_id=None):
    return os.path.join(
        _ensure_subdir(CACHE_SUBDIR_SOURCE),
        _key(imdb_id, season, episode, source_lang, source_id) +
        '.{0}.srt'.format(source_lang))


def metadata_path(imdb_id):
    safe = hashlib.sha1(str(imdb_id).encode('utf-8')).hexdigest()[:16]
    return os.path.join(_ensure_subdir(CACHE_SUBDIR_METADATA),
                        '{0}_{1}.json'.format(str(imdb_id) or 'unknown', safe))


def load_text(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = f.read()
        # Refresh atime/mtime so LRU eviction tracks usage.
        try:
            now = time.time()
            os.utime(path, (now, now))
        except OSError:
            pass
        return data
    except (IOError, OSError, UnicodeDecodeError):
        return None


def save_text(path, content):
    if not path:
        return False
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except (IOError, OSError):
        return False


def load_json(path):
    raw = load_text(path)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return None


def save_json(path, data):
    try:
        return save_text(path, json.dumps(data, ensure_ascii=False, indent=0))
    except (TypeError, ValueError):
        return False


# Zero-byte markers written NEXT TO a translation, not standing on their own.
# Longest first: '.emb2.shared' has to be stripped whole, because '<path>.emb2'
# is only a marker KEY (translate._pool_marker) and no such file is ever
# written -- taking it as the parent would make every embedded marker look
# orphaned.
#   .shared        pool.
#   .emb2.shared   pool._marker_path(translate._pool_marker(p, 'ai_emb')).
#   .google        srt.is_google_translated -- this file is machine
#                  translation and must never reach the community pool.
#   .release       the source release name, used to tag a pool upload.
#   .gpref         the language of its gender reference: no gender proofread
#                  after a Hebrew one (translate._gp_ref_mark).
_SIDECARS = ('.emb2.shared', '.shared', '.google', '.release', '.gpref')


def _sidecar_parent(path):
    """The translation a marker belongs to, or '' when this is not a marker."""
    for suf in _SIDECARS:
        if path.endswith(suf):
            return path[:-len(suf)]
    return ''


def _walk_cache_files():
    """Yield (full_path, atime_or_mtime, size_bytes) for every file
    under the cache root.

    A SIDECAR IS AS RECENT AS THE FILE IT DESCRIBES. load_text() touches only
    the translation, so a marker beside a file that is read every week still
    ages out on its own mtime. For '.google' that is a correctness bug rather
    than untidiness: once the marker is gone is_google_translated() answers
    False and the next cache hit backfills machine translation into the
    community pool, which translate.py and srt.py both say must never happen.
    '.shared' has the same shape -- lose it and the file is re-uploaded.

    A marker with NO parent keeps its own recency. That is what matters for
    '.release', which is written when the reference is chosen -- one to three
    minutes before cache.save_text() creates the translation -- so a prune() in
    that window must not treat it as an orphan and delete it mid-job. Once it
    IS old and still parentless, it is collected normally.

    max() rather than plain inheritance is defensive only: it would keep a
    freshly-rewritten marker beside a parent that is already past its TTL. No
    test covers that because no caller currently produces it -- the distinction
    is not load-bearing today, and it is written here so the next reader does
    not mistake it for a behaviour that is being relied on.

    Note this materialises the file table before yielding, where it used to
    stream: a sidecar cannot be scored without its parent's stat, and the
    parent may come later in the walk. At the 200 MB default that is a few MB;
    at the 2000 MB maximum roughly 35 MB, briefly, on a background thread.
    """
    root = kodi_utils.cache_dir()
    stats = {}
    for dirpath, _dirnames, filenames in os.walk(root):
        for fn in filenames:
            p = os.path.join(dirpath, fn)
            try:
                st = os.stat(p)
            except OSError:
                continue
            stats[p] = (max(st.st_atime, st.st_mtime), st.st_size)
    for p, (recency, size) in stats.items():
        parent = _sidecar_parent(p)
        if parent:
            prec = stats.get(parent)
            if prec:
                recency = max(recency, prec[0])
        yield p, recency, size


def prune():
    """Apply TTL + size-cap eviction. Safe to run any time; returns
    (files_removed, bytes_freed) for caller telemetry."""
    ttl_days = kodi_utils.get_int('cache_ttl_days', 180)
    cap_mb   = kodi_utils.get_int('cache_size_mb', 200)
    cap_bytes = max(10, cap_mb) * 1024 * 1024
    cutoff    = time.time() - ttl_days * 86400

    removed = 0
    freed   = 0

    # A translation and its provenance are one eviction unit. Delete the
    # parent first: if removal fails, keep its markers as well. Group recency
    # preserves fresh sidecars and parentless in-flight release markers.
    groups = {}
    for path, recency, size in _walk_cache_files():
        parent = _sidecar_parent(path) or path
        groups.setdefault(parent, []).append((path, recency, size))

    def evict(parent, members):
        count = amount = 0
        ordered = sorted(members, key=lambda row: row[0] != parent)
        for path, _recency, size in ordered:
            try:
                os.remove(path)
                count += 1
                amount += size
            except OSError:
                if path == parent and os.path.exists(parent):
                    break  # Never strip provenance from a surviving parent.
        return count, amount

    survivors = []
    for parent, members in groups.items():
        recency = max(row[1] for row in members)
        size = sum(row[2] for row in members)
        if recency < cutoff:
            n, amount = evict(parent, members)
            removed += n
            freed += amount
            if amount < size:
                # Keep failed deletions accounted for in the size budget.
                remaining = [row for row in members if os.path.exists(row[0])]
                if remaining:
                    survivors.append((parent, recency, remaining))
        else:
            survivors.append((parent, recency, members))

    total = sum(row[2] for _, _, members in survivors for row in members)
    target = int(cap_bytes * 0.8)
    if total > cap_bytes:
        for parent, _recency, members in sorted(survivors, key=lambda row: row[1]):
            if total <= target:
                break
            n, amount = evict(parent, members)
            removed += n
            freed += amount
            total -= amount
    return removed, freed



def clear_all():
    """Wipe every file under cache/. Returns count removed."""
    count = 0
    for path, _r, _s in _walk_cache_files():
        try:
            os.remove(path)
            count += 1
        except OSError:
            pass
    return count


def total_size_mb():
    total = 0
    for _p, _r, s in _walk_cache_files():
        total += s
    return total / (1024.0 * 1024.0)
