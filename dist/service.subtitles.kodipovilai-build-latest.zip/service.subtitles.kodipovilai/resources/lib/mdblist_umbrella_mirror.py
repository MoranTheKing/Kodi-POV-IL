# One MDBList authorisation for both add-ons.
#
# Connecting MDBList used to mean doing it twice: once here (an API key,
# paired by QR) and once inside Umbrella (a short code typed on mdblist.com).
# That is not a limitation of MDBList -- it was ours. POV and Umbrella want
# the SAME credential and get it the same way:
#
#   POV      menus/myservices.py MDBList.set()
#              POST oauth/device-authorization/  -> user_code + QR
#              poll oauth/token/                 -> access_token, refresh_token
#              mdblist.token = access_token, mdblist.refresh = refresh_token
#   Umbrella modules/mdblist.py mdblistAuth()
#              POST oauth/device-authorization/  -> user_code
#              poll oauth/token/                 -> access_token, refresh_token
#              mdblist.token = access_token
#
# and both then send `Authorization: Bearer <access_token>` to the same
# api.mdblist.com. So one authorisation produces a token both can use, and the
# second trip round the loop bought nothing.
#
# POV even says so itself, in indexers/mdblist_api.py:
#
#     if not bool(get_setting('mdblist.refresh')): params['apikey'] = ...
#     else: headers = {'Authorization': 'Bearer %s' % ...}
#
# -- an api_key when there is no refresh token, a Bearer when there is. That
# line is also the test this module relies on: a POV `mdblist.token` with NO
# `mdblist.refresh` beside it is an API KEY, not an access token, and copying
# it into Umbrella would produce exactly the failure this replaces (connected,
# and empty), because Umbrella only ever sends Bearer. So we mirror only when
# POV holds a real OAuth pair.
#
# THE REFRESH. The two add-ons have different OAuth client_ids -- POV's is a
# hidden setting, Umbrella's is hardcoded -- and a refresh token belongs to
# the client it was issued to. Sharing one token would leave whichever add-on
# did not issue it unable to refresh. So Umbrella is deliberately given the
# access token and NO refresh token, because its own refresher begins:
#
#     refresh_token = getSetting('mdblist.refresh.token')
#     if not refresh_token: return
#
# With that empty it never tries, never fails, and simply uses what it is
# given. POV owns the refreshing -- with its own client_id, which is the only
# one that can -- and this module re-mirrors whenever POV's token has moved.
# Run at every startup, so a refresh POV did yesterday reaches Umbrella today.
#
# NOT YET PROVEN IN THE FIELD: that MDBList accepts a token issued to POV's
# client for calls Umbrella makes. It should -- an OAuth resource server
# authenticates the user behind the token, not the client presenting it -- but
# it is an assumption until a real account has run it, and it is written down
# here rather than left implied.

try:
    import xbmcaddon
except Exception:
    xbmcaddon = None

try:
    from resources.lib import kodi_utils
except Exception:
    kodi_utils = None

try:
    from resources.lib import addon_presence
except Exception:
    addon_presence = None

try:
    from resources.lib import addon_settings_safe
except Exception:
    addon_settings_safe = None

try:
    from resources.lib import umbrella_watch_source
except Exception:
    umbrella_watch_source = None


POV_ADDON_ID = 'plugin.video.pov'
UMBRELLA_ADDON_ID = 'plugin.video.umbrella'

# POV's pair. `refresh` is what proves the token is OAuth and not an API key.
POV_TOKEN = 'mdblist.token'
POV_REFRESH = 'mdblist.refresh'

# Umbrella's. Its refresh is written EMPTY on purpose -- see the header.
UMB_TOKEN = 'mdblist.token'
UMB_REFRESH = 'mdblist.refresh.token'


UMBRELLA_GUARD_PROPERTY = 'umbrella.updateSettings'


def _log(msg, level='INFO'):
    if kodi_utils is None:
        return
    try:
        kodi_utils.log('mdblist_umbrella_mirror: ' + msg, level=level)
    except Exception:
        pass


def _reader(addon_id):
    """A read function backed by ONE Addon object, for the life of this call.

    Constructing xbmcaddon.Addon() re-parses and re-validates the whole of
    that add-on's settings.xml -- POV declares 251 settings, Umbrella 545 --
    and this runs every minute now, so a fresh construction per key was
    several hundred reparses a minute on a set-top box.

    One per add-on per pass, and deliberately NOT cached between passes: a
    long-lived object can go stale against a file another process rewrote,
    and the whole reason this runs on a timer is to notice the token POV
    refreshed in the background.

    Returns None for every key when the add-on is not installed or cannot be
    opened -- which is not the same as ''.

    ASKED THROUGH addon_presence, not by construction. On a device without
    Umbrella the bare construction wrote `EXCEPTION: Unknown addon id
    'plugin.video.umbrella'` at ERROR level -- Kodi writes it BEFORE raising,
    so catching it does not unwrite it -- and this runs every sixty seconds
    for as long as Kodi is up. A field log shows exactly that, one red line a
    minute, on a device whose only fault was not having an optional add-on."""
    if xbmcaddon is None:
        return lambda _key: None
    addon = (addon_presence.addon(addon_id)
             if addon_presence is not None else None)
    if addon is None:
        return lambda _key: None

    def _get(key):
        try:
            return (addon.getSetting(key) or '').strip()
        except Exception:
            return None
    return _get


def mirror(reclaim=False):
    """Give Umbrella whatever MDBList access token POV currently holds.

    `reclaim` comes from exactly one place: POV's Connect Services row, which
    measures the token across POV's own set() and so can tell a real
    authorisation from a declined dialog. The timer and the startup pass never
    pass it, and nothing else may.

    Returns 'no_pov' | 'no_umbrella' | 'no_token' | 'api_key_only'
    | 'unchanged' | 'mirrored' | 'write_failed'. Never raises."""
    if addon_settings_safe is None:
        return 'write_failed'

    pov = _reader(POV_ADDON_ID)
    token = pov(POV_TOKEN)
    if token is None:
        return 'no_pov'
    if not token:
        # POV has nothing. Deliberately NOT clearing Umbrella: it may hold a
        # perfectly good token of its own, authorised inside Umbrella before
        # any of this existed, and taking that away would be a regression
        # dressed up as tidiness. Answered before Umbrella is opened, because
        # on a box with no MDBList this is every pass of a per-minute timer.
        return 'no_token'

    refresh = pov(POV_REFRESH)
    if refresh is None:
        return 'no_pov'
    if not refresh:
        # An API key, not an access token. Umbrella only sends Bearer, so
        # copying this would reproduce the exact bug this module replaces.
        return 'api_key_only'

    umbrella = _reader(UMBRELLA_ADDON_ID)
    umb_token = umbrella(UMB_TOKEN)
    if umb_token is None:
        return 'no_umbrella'

    # Have Umbrella actually READ from MDBList. Connecting it does not do
    # that on its own; see umbrella_watch_source for the rules. Computed
    # BEFORE the token comparison below, because someone already connected
    # has a token that matches and would otherwise never reach this -- and
    # they are exactly the people who reported the missing ticks.
    # may_replace=(TRAKT,): a Trakt value WE put here loses to MDBList, so the
    # preference holds even for somebody who connected Trakt first.
    wanted, settle_keys = [], None
    if umbrella_watch_source is not None:
        wanted, settle_keys = umbrella_watch_source.pairs(
            umbrella, umbrella_watch_source.MDBLIST,
            may_replace=(umbrella_watch_source.TRAKT,),
            reclaim=reclaim)

    if umb_token != token:
        wanted = [(UMB_TOKEN, token), (UMB_REFRESH, '')] + wanted
    elif not wanted:
        # Nothing to write -- but we DID look at the two watch-source
        # settings, and the look is the one we get. Recording it on this path
        # too is what stops a later, deliberate move back to Local being
        # quietly undone: this branch is reached on almost every pass (token
        # unchanged, source already chosen), so leaving it unrecorded means
        # the "once" rule never actually takes hold and the next pass after
        # the user moves the setting claims it all over again.
        if settle_keys and umbrella_watch_source is not None:
            umbrella_watch_source.settle(settle_keys)
        return 'unchanged'

    changed, _restored, failed = addon_settings_safe.apply(
        UMBRELLA_ADDON_ID, tuple(wanted),
        guard_property=UMBRELLA_GUARD_PROPERTY)
    if failed:
        # Record the watch-source keys that DID stick. A batch can fail on an
        # unrelated key -- the token -- while these two land perfectly well,
        # and leaving them unrecorded is how our own write gets read back as
        # the user's on the next pass.
        if settle_keys and umbrella_watch_source is not None:
            umbrella_watch_source.settle(settle_keys, skip=failed)
        _log('mirror did not stick ({0}) -- will retry next startup'
             .format(', '.join(failed)), level='WARNING')
        return 'write_failed'
    if settle_keys and umbrella_watch_source is not None:
        umbrella_watch_source.settle(settle_keys)
    if not changed:
        return 'unchanged'
    _log('Umbrella now shares POV\'s MDBList authorisation'
         + (' and takes watched state from it'
            if any(k in (umbrella_watch_source.INDICATORS,
                         umbrella_watch_source.SCROBBLE)
                   for k in changed) else ''), level='INFO')
    return 'mirrored'
