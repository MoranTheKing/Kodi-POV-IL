# A debrid that says "no" with HTTP 200, and a log that keeps none of it.
#
# THE REPORT: AllDebrid stopped working. The follow-up log said nothing about
# why -- no HTTP error, no exception, just sources that would not play.
#
# WHY THE LOG WAS EMPTY. AllDebrid does not signal refusals with status codes.
# Every answer is 200 OK, and the refusal is in the body:
#
#     {"status": "error",
#      "error": {"code": "AUTH_BAD_APIKEY", "message": "The auth apikey is invalid"}}
#
# POV's _request logs only `if not response.ok`. A 200 is ok, so nothing is
# logged; the body is then handed on, `if 'data' in response and status ==
# 'success'` is false, and the raw envelope travels up to a caller that wanted
# a list. The caller reports "no sources". The reason -- which AllDebrid spelt
# out in words -- is discarded one line after it arrives.
#
# Checked against the live API with no credentials, so the shapes below are
# observed rather than assumed: v4/user and v4/magnet/upload both answer 200
# with AUTH_MISSING_APIKEY; v4/magnet/instant answers 404. The endpoints are
# fine. AllDebrid is refusing the account and naming the refusal in a field
# nobody reads.
#
# TORBOX HAS THE SAME DISEASE with a different envelope -- {"success": false,
# "error": "...", "detail": "..."} at 200 -- and its unwrap line is worse: it
# tests `'success' in response`, which is true when success is FALSE, so on an
# error it returns response['data'] (null) and the error string never leaves
# the function.
#
# WHAT THIS DOES: one log line, at the moment the envelope is decoded, naming
# the endpoint and the provider's own code and message. It changes no control
# flow whatsoever -- POV goes on to do exactly what it did before, and the user
# sees exactly what they saw before. The difference is that the NEXT log
# somebody sends says which of "not connected", "key rejected", "banned" and
# "not premium" it was, instead of leaving four possibilities open.
#
# TWO SITES, NOT FOUR. Premiumize (`{"status":"error","message":...}` at 200)
# and Real-Debrid (proper status codes, but its log line prints the HTTP reason
# phrase -- "Forbidden" -- and drops RD's own error string) have the same
# defect. Both end _request with `return response.json() if ... else response`,
# a single expression: reporting the error there means REWRITING a line POV
# wrote, not inserting one. Every patcher here is pure insertion so that the
# revert is byte-exact, and that is worth more than two more log lines. They
# are recorded here so nobody has to rediscover them.
#
# Modelled on pov_debrid_unbound_guard_patcher next door, down to the revert
# walk and the BOM note; read that file first if this one needs changing.


# POV 6.08.14 MOVED THESE FILES AND THE DEFECTS CAME WITH THEM. The debrid API
# clients were relocated from resources/lib/debrids/ to resources/lib/indexers/
# (the debrids/ name was reused for the cloud scrapers that used to live in
# scrapers/). The anchors below still match, byte for byte, in the new
# location -- so this patch did not become unnecessary, it silently stopped
# being applied, on a device where the thing it prevents still happens.
#
# `_pov_path` therefore tries the recorded folder first and then the other one,
# rather than pinning either. Both layouts are live in the field right now.

import os

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

try:
    from resources.lib import kodi_utils
except Exception:
    kodi_utils = None


POV_ADDON_ID = 'plugin.video.pov'

MARKER = '# AI_SUBS_POV_DEBRID_ERRLOG_v1'
# Prefix, never an enumerated list of predecessors.
_MARKER_ANY = '# AI_SUBS_POV_DEBRID_ERRLOG_v'

# The text every injected line carries, so a user's log can be grepped for it
# and so nobody mistakes these lines for something POV itself prints.
_TAG = 'KODI_POV_IL'

# (label, relative path, anchor, the condition that means "this is a refusal")
#
# The anchor is the decode line plus the unwrap line beneath it. The decode
# line alone is not unique across POV's debrid modules; the pair is unique
# inside each file, and carrying both makes the insertion point unambiguous --
# the block goes between them, after the body is a dict and before POV throws
# the envelope away.
# (label, relative path, anchor, the condition that means "this is a refusal",
#  the expression naming WHAT was refused)
#
# ONE EXPRESSION, AND NO CHAINED .get. This carried a separate code and message
# expression, and AllDebrid's read `(response.get('error') or {}).get('code')`.
# That is a bet that `error` is a dict -- `or {}` only rescues a FALSY value,
# so an `error` that is a string, a list or a number sails through and .get
# raises AttributeError. The guard around the line then swallows it and NOTHING
# is logged, for exactly the case a diagnostic is worth most: an answer whose
# shape we did not expect. Logging the whole value instead cannot raise on a
# shape, and reads no worse -- a dict prints its own code and message.
_SITES = (
    ('alldebrid', 'resources/lib/debrids/alldebrid_api.py',
     "\t\tresponse = response.json() if 'json' in response.headers.get('Content-Type', '') else response\n"
     "\t\tif 'data' in response and response.get('status') == 'success': response = response['data']\n",
     "response.get('status') == 'error'",
     "response.get('error')"),
    ('torbox', 'resources/lib/debrids/torbox_api.py',
     "\t\tresponse = response.json() if 'json' in response.headers.get('Content-Type', '') else response\n"
     "\t\tif not self._is_control(path) and 'data' in response and 'success' in response: response = response['data']\n",
     "response.get('success') is False",
     "(response.get('error'), response.get('detail'))"),
)

# A THIRD SITE, AND A DIFFERENT SHAPE, so it has its own anchor and its own
# block rather than being forced into the table above.
#
# THE REPORT: "sometimes the numbers go up while it searches, and it still says
# no results and never shows the list -- and only on Premiumize". Both halves
# of that are explained by five lines of POV:
#
#     def check_cache(self, hashes):
#         result = self._post('cache/check', data)
#         return [h for h, cached in zip(hashes, result['response']) if cached]
#
# A bare subscript. Premiumize refuses with HTTP 200 and
# {"status":"error","message":...}, which has no 'response' key, so this is a
# KeyError -- and modules/debrid.py's cache_check wraps the whole thing in
# `except: pass` and returns an empty cached list. Every source is then
# "uncached", a build set to show cached sources filters them all out, and the
# user gets "no results" AFTER watching the counters climb.
#
# WHY ONLY PREMIUMIZE, which is the question that makes this a second cause
# and not the same one: it is not that the other providers are written more
# carefully -- TorBox's line has the same shape of fragility. It is that this
# user's Premiumize is actually saying no. Nobody could see that, because the
# refusal was destroyed by a bare except two frames up.
#
# LOG ONLY. The KeyError still happens and is still swallowed exactly as
# before; POV behaves identically. What changes is that the next log says
# which refusal it was instead of showing an empty list with no explanation.
_PREMIUMIZE = (
    'premiumize', 'resources/lib/debrids/premiumize_api.py',
    "\t\tresult = self._post(url, data)\n"
    "\t\treturn [h for h, cached in zip(hashes, result['response']) if cached]\n",
    "\t\tresult = self._post(url, data)\n"
    "\t\tif isinstance(result, dict) and 'response' not in result:  {marker}\n"
    "\t\t\ttry: kodi_utils.logger(__name__, '{tag} refused cache/check -- %s'"
    " % (result,))\n"
    "\t\t\texcept Exception: pass\n"
    "\t\treturn [h for h, cached in zip(hashes, result['response']) if cached]\n",
)


def _log(msg, level='INFO'):
    if kodi_utils is None:
        return
    try:
        kodi_utils.log('pov_debrid_error_log_patcher: ' + msg, level=level)
    except Exception:
        pass


def _fitter(content):
    eol = '\r\n' if '\r\n' in content else '\n'
    return (lambda t: t.replace('\n', eol)) if eol != '\n' else (lambda t: t)


# The marker inside a shape, so a block written by an older version can be
# recognised whatever its version number was. A literal placeholder and
# str.replace, not str.format: the block contains percent formatting.
_MARKER_SLOT = '<<<MARKER>>>'


def _found_marker(content):
    """The marker actually present -- the prefix plus its version digits."""
    at = content.find(_MARKER_ANY)
    if at < 0:
        return ''
    end = at + len(_MARKER_ANY)
    while end < len(content) and content[end].isdigit():
        end += 1
    return content[at:end]


def _revert(content, is_error, error_expr, eol='\n'):
    """Delete a previous version's injected block, by matching the WHOLE of it.

    NOT the indent walk its sibling patcher uses. That walk removes "the
    marked line and everything indented deeper", which is right until
    something else is sitting there: a review built a file with an unrelated,
    deeper-indented line straight after an old marker and watched the walk
    swallow it, report success, and leave a file that still compiled. Deleting
    somebody else's line out of somebody else's add-on is worse than any
    failure to upgrade.

    Matching the whole block cannot do that. A block that is not exactly what
    a version of this file wrote matches nothing, and the caller then reports
    revert_failed and leaves the file alone -- which is the right answer for a
    file we no longer recognise.
    """
    marker = _found_marker(content)
    if not marker:
        return content
    fit = _fitter(content)
    shape = _block(is_error, error_expr).replace(MARKER, _MARKER_SLOT)
    injected = fit(shape.replace(_MARKER_SLOT, marker))
    if injected in content:
        return content.replace(injected, '', 1)
    return content


def _pov_path(rel):
    """POV's file, wherever this version of POV keeps it.

    6.08.14 moved the debrid API clients from debrids/ to indexers/ without
    changing them, so a path recorded against one layout has to be tried
    against the other. Returns '' when neither exists, which every caller
    already treats as "not this device's POV".
    """
    if xbmcvfs is None:
        return ''
    try:
        base = xbmcvfs.translatePath(
            'special://home/addons/' + POV_ADDON_ID + '/')
    except Exception:
        return ''
    for candidate in _relocations(rel, base):
        p = os.path.join(base, *candidate.split('/'))
        if os.path.isfile(p):
            return p
    return ''


# The one rename, and its inverse. A list rather than a string swap so a path
# that mentions neither folder is returned untouched and exactly once.
_MOVED = (('resources/lib/debrids/', 'resources/lib/indexers/'),
          ('resources/lib/indexers/', 'resources/lib/debrids/'))


def _live_pkg(base):
    """Which package POV ITSELF imports these clients from, or ''.

    ORDER MATTERS AND EXISTENCE IS NOT ENOUGH, which the first version of this
    got wrong. Both folders ship in 6.08.14 -- debrids/ holds the cloud
    scrapers now -- so "try the recorded path, then the other" happily patches
    a stale debrids/torbox_api.py left behind by an earlier layout while the
    file POV actually imports, indexers/torbox_api.py, is never touched. The
    patch then reports `patched` having fixed nothing, which is worse than
    reporting `no_file`.

    POV states the answer in one line of modules/debrid.py:
        6.08.13   from debrids  import alldebrid_api, ... torbox_api, ...
        6.08.14   from indexers import alldebrid_api, ... torbox_api, ...
    """
    p = os.path.join(base, 'resources', 'lib', 'modules', 'debrid.py')
    try:
        with open(p, encoding='utf-8', errors='replace') as fh:
            text = fh.read()
    except Exception:
        return ''
    for line in text.splitlines():
        s = line.strip()
        for pkg in ('indexers', 'debrids'):
            if s.startswith('from %s import ' % pkg) and '_api' in s:
                return pkg
    return ''


def _relocations(rel, base=''):
    out = [rel]
    for a, b in _MOVED:
        if rel.startswith(a):
            alt = b + rel[len(a):]
            if alt not in out:
                out.append(alt)
    pkg = _live_pkg(base) if base else ''
    if pkg:
        # Put the folder POV imports from first, whatever we recorded.
        out.sort(key=lambda c: 0 if '/%s/' % pkg in c else 1)
    return out


def _drop_pycache(path):
    stem = os.path.basename(path).split('.')[0] + '.'
    pycache = os.path.join(os.path.dirname(path), '__pycache__')
    if not os.path.isdir(pycache):
        return
    for fn in os.listdir(pycache):
        if fn.startswith(stem) and fn.endswith('.pyc'):
            try:
                os.remove(os.path.join(pycache, fn))
            except OSError:
                pass


def _block(is_error, error_expr):
    """The three lines that go in. Tabs, because these files use tabs.

    Wrapped in its own try/except and reading only through `.get`, because a
    log line is not worth a single new way for _request to raise. `isinstance`
    first: on a non-JSON reply `response` is still the requests object, which
    has no .get at all.
    """
    return (
        "\t\tif isinstance(response, dict) and {0}:  {1}\n"
        "\t\t\ttry: kodi_utils.logger(__name__, '{2} refused %s -- %s'"
        " % (path, {3}))\n"
        "\t\t\texcept Exception: pass\n"
    ).format(is_error, MARKER, _TAG, error_expr)


def _patch_one(rel, anchor, is_error, error_expr):
    """Returns 'no_file' | 'unchanged' | 'patched' | 'repatched' | 'unmatched'
    | 'read_failed' | 'write_failed' | 'compile_failed' | 'revert_failed'."""
    path = _pov_path(rel)
    if not path:
        return 'no_file'
    try:
        with open(path, encoding='utf-8', newline='') as f:
            content = f.read()
    except Exception as e:
        _log('{0}: read failed: {1}'.format(rel, e), level='WARNING')
        return 'read_failed'

    fit = _fitter(content)
    eol = '\r\n' if '\r\n' in content else '\n'

    # `MARKER in content` alone used to answer this, and it short-circuits: a
    # file carrying the current block AND an orphan from some other version
    # was reported unchanged, and the orphan stayed for good, unmentioned.
    # It cannot arise from this module -- it reverts then injects, or fails
    # without injecting -- but "cannot happen here" is not the same as "is
    # not worth noticing in somebody else's file".
    if MARKER in content and content.count(_MARKER_ANY) == 1:
        return 'unchanged'
    if MARKER in content:
        _log('{0}: carries more than one injected block; leaving it alone '
             'rather than guessing which to remove'.format(rel),
             level='WARNING')
        return 'revert_failed'

    repatch = False
    if _MARKER_ANY in content:
        content = _revert(content, is_error, error_expr, eol)
        repatch = True
        if _MARKER_ANY in content:
            _log('{0}: could not remove an older injection'.format(rel),
                 level='WARNING')
            return 'revert_failed'

    # count, not `in`: a refactor that DUPLICATED this shape is unrecognised
    # rather than patched at whichever copy happens to come first.
    if content.count(fit(anchor)) != 1:
        _log('{0}: the expected shape is not there exactly once -- POV may '
             'have refactored it; leaving the file alone'.format(rel),
             level='WARNING')
        return 'unmatched'

    decode, _, unwrap = anchor.partition('\n')
    new_content = content.replace(
        fit(anchor),
        fit(decode + '\n' + _block(is_error, error_expr) + unwrap),
        1)

    try:
        # lstrip the BOM for the CHECK only -- see the long note on the same
        # line in pov_debrid_unbound_guard_patcher for why stripping it on the
        # way in would be worse.
        compile(new_content.lstrip('﻿'), path, 'exec')
    except SyntaxError as e:
        _log('{0}: compile check failed, not writing: {1}'.format(rel, e),
             level='WARNING')
        return 'compile_failed'

    tmp = path + '.aitmp'
    try:
        with open(tmp, 'w', encoding='utf-8', newline='') as f:
            f.write(new_content)
        os.replace(tmp, path)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        _log('{0}: write failed: {1}'.format(rel, e), level='WARNING')
        return 'write_failed'

    _drop_pycache(path)
    return 'repatched' if repatch else 'patched'


def _patch_block(rel, broken, fixed):
    """Replace one whole block with another. Same guards as _patch_one.

    A second function rather than a third column on _SITES: those two share an
    anchor shape and this one does not, and bending the table to hold both
    would make every future reader work out which columns apply.
    """
    path = _pov_path(rel)
    if not path:
        return 'no_file'
    try:
        with open(path, encoding='utf-8', newline='') as f:
            content = f.read()
    except Exception as e:
        _log('{0}: read failed: {1}'.format(rel, e), level='WARNING')
        return 'read_failed'
    fit = _fitter(content)
    marker = _found_marker(content)
    want = fit(fixed.format(marker=MARKER, tag=_TAG))
    if want in content and content.count(_MARKER_ANY) == 1:
        return 'unchanged'
    if marker and marker != MARKER:
        aged = fit(fixed.format(marker=marker, tag=_TAG))
        if aged in content:
            content = content.replace(aged, fit(broken), 1)
        else:
            _log('{0}: an older injection is not the shape this file wrote; '
                 'leaving it alone'.format(rel), level='WARNING')
            return 'revert_failed'
    if content.count(fit(broken)) != 1:
        _log('{0}: the expected shape is not there exactly once -- POV may '
             'have refactored it; leaving the file alone'.format(rel),
             level='WARNING')
        return 'unmatched'
    new_content = content.replace(fit(broken), want, 1)
    try:
        compile(new_content.lstrip('\ufeff'), path, 'exec')
    except SyntaxError as e:
        _log('{0}: compile check failed, not writing: {1}'.format(rel, e),
             level='WARNING')
        return 'compile_failed'
    tmp = path + '.aitmp'
    try:
        with open(tmp, 'w', encoding='utf-8', newline='') as f:
            f.write(new_content)
        os.replace(tmp, path)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        _log('{0}: write failed: {1}'.format(rel, e), level='WARNING')
        return 'write_failed'
    _drop_pycache(path)
    return 'repatched' if marker and marker != MARKER else 'patched'


def ensure_patched():
    """Idempotent. Never raises. Returns a comma-joined per-file status,
    e.g. 'alldebrid=patched, torbox=patched'.

    Per FILE, not all-or-none: two independent providers, and a POV refactor
    that moves one is no reason to leave the other silent.
    """
    if xbmcvfs is None:
        return 'no_pov'
    out = []
    for label, rel, anchor, is_error, error_expr in _SITES:
        try:
            st = _patch_one(rel, anchor, is_error, error_expr)
        except Exception as e:
            _log('{0}: unexpected failure: {1}'.format(rel, e),
                 level='WARNING')
            st = 'read_failed'
        out.append('%s=%s' % (label, st))
    label, rel, broken, fixed = _PREMIUMIZE
    try:
        st = _patch_block(rel, broken, fixed)
    except Exception as e:
        _log('{0}: unexpected failure: {1}'.format(rel, e), level='WARNING')
        st = 'read_failed'
    out.append('%s=%s' % (label, st))
    if any(s.endswith('=patched') or s.endswith('=repatched') for s in out):
        _log('a debrid that refuses the account now says so in the log '
             'instead of turning into "no sources"')
    return ', '.join(out)
