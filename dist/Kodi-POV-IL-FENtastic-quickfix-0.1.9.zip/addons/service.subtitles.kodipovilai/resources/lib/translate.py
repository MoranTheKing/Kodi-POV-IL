# Orchestration: take a video metadata dict and a target language,
# return either a list of candidate subtitle entries (for the
# search dialog) or a final SRT path (for the download step).
#
# Source policy (we do NOT touch OpenSubtitles ourselves -- the
# user's existing subtitle addons (DarkSubs, OS-by-OS, etc.) handle
# all sourcing and have their own working quotas/keys, so we just
# read whatever they drop into Kodi's temp dir):
#
#   1. Hebrew SRT next to the video         -> hand it back as-is
#   2. Hebrew SRT in special://temp/         -> hand it back as-is
#   3. Source-lang SRT next to the video    -> translate to Hebrew
#   4. Source-lang SRT in special://temp/    -> translate to Hebrew
#                                              (lets the user grab
#                                              English from
#                                              DarkSubs/OS, then
#                                              come back to us)
#
# Two top-level entry points:
#   list_candidates(info)  -> [{title, language, link, ...}]
#   resolve(link, info)    -> path-to-srt-on-disk

import json
import os
import time
import urllib.parse

from . import cache
from . import gemini
from . import kodi_utils
from . import language_detect
from . import local_subs
from . import prompt
from . import srt
from . import tmdb_helper

# Iteration order = priority order. settings.xml exposes
# checkboxes -- we filter the disabled ones out at runtime.
ALL_SOURCE_LANGS = [
    ('en', 'src_english'),
    ('es', 'src_spanish'),
    ('de', 'src_german'),
    ('fr', 'src_french'),
    ('pt', 'src_portuguese'),
]


def _enabled_sources():
    return [code for code, key in ALL_SOURCE_LANGS
            if kodi_utils.get_bool(key, code in ('en', 'es'))]


def _encode_link(payload):
    return urllib.parse.quote(json.dumps(payload, ensure_ascii=False))


def _decode_link(link):
    try:
        return json.loads(urllib.parse.unquote(link))
    except (ValueError, TypeError):
        return None


def _lang_display(code):
    return {
        'en': 'English', 'es': 'Spanish', 'fr': 'French',
        'de': 'German', 'pt': 'Portuguese', 'he': 'Hebrew',
    }.get(code, code or 'Unknown')


# ---- search ----------------------------------------------------------

def list_candidates(info):
    """Build the list Kodi's subtitle dialog will render.

    Returns a list of dicts with keys: filename, language, link,
    sync, rating. Empty list if nothing plausible is available.
    """
    filepath = info.get('filepath') or ''

    # Collect candidate source files from the two filesystem
    # locations we look at. By-language dicts, so first match wins
    # per language.
    alongside = {}
    for path, lang in local_subs.find_alongside(filepath):
        if lang and lang not in alongside:
            alongside[lang] = path

    in_temp = {}
    for entry in local_subs.find_in_temp():
        lang = entry['lang']
        if lang and lang not in in_temp:
            in_temp[lang] = entry['path']

    results = []

    # 1. Hebrew passthrough -- if there's already a Hebrew SRT we
    #    can hand to Kodi, no need to translate anything.
    have_hebrew = False
    if 'he' in alongside:
        have_hebrew = True
        results.append({
            'filename': os.path.basename(alongside['he']),
            'language': 'he',
            'link': _encode_link({
                'type': 'passthrough', 'path': alongside['he'],
            }),
            'sync': 'true',
            'rating': '5',
            'is_hi': False, 'is_hd': False,
        })
    elif 'he' in in_temp:
        # Already-loaded Hebrew sub from another addon -- nothing
        # for us to do, just point Kodi at the file.
        have_hebrew = True
        results.append({
            'filename': os.path.basename(in_temp['he']),
            'language': 'he',
            'link': _encode_link({
                'type': 'passthrough', 'path': in_temp['he'],
            }),
            'sync': 'true',
            'rating': '5',
            'is_hi': False, 'is_hd': False,
        })

    skip_when_hebrew = kodi_utils.get_bool('skip_if_hebrew', True)
    if have_hebrew and skip_when_hebrew:
        return results

    # 2. For each enabled source language, surface ONE "translate
    #    this" entry. Prefer an alongside file (always available
    #    re-watches), then a recently-downloaded sub in temp.
    sources = _enabled_sources()
    seen_langs = set()
    for src_lang in sources:
        if src_lang in seen_langs:
            continue

        local_path = alongside.get(src_lang) or in_temp.get(src_lang)
        if not local_path:
            continue

        seen_langs.add(src_lang)
        source_label = _lang_display(src_lang)
        # Hint to the user where the source came from so it's
        # obvious why we're offering this in particular.
        source_origin = ('local file' if alongside.get(src_lang)
                         else 'loaded by another addon')
        results.append({
            'filename': 'AI Hebrew (translate {0} {1})'.format(
                source_label, source_origin),
            'language': 'he',
            'link': _encode_link({
                'type': 'ai',
                'source_lang': src_lang,
                'local_path': local_path,
            }),
            'sync': 'false',
            'rating': '4' if src_lang == 'en' else '3',
            'is_hi': False, 'is_hd': False,
        })

    return results


# ---- download / translate -------------------------------------------

def resolve(link, info, progress_cb=None):
    """Return a filesystem path to the SRT for the chosen link.

    For passthrough, hand back the existing file path. For ai
    entries, translate (or read from cache) and return the cached
    file's path. progress_cb, if provided, is called as
    progress_cb(chunk_index, total_chunks)."""
    payload = _decode_link(link)
    if not payload:
        return None

    kind = payload.get('type')

    imdb_id = (info.get('imdb_id') or '').strip()
    season  = info.get('season') or ''
    episode = info.get('episode') or ''

    if kind == 'passthrough':
        path = payload.get('path')
        if path and os.path.isfile(path):
            return path
        return None

    if kind != 'ai':
        return None

    source_lang = payload.get('source_lang') or 'en'

    # Already translated this exact tuple? Return the cached file.
    translated = cache.translated_path(imdb_id, season, episode, source_lang)
    if os.path.isfile(translated):
        kodi_utils.log('Cache hit: ' + translated, level='INFO')
        try:
            now = time.time()
            os.utime(translated, (now, now))
        except OSError:
            pass
        return translated

    # Read the source SRT from the local path we recorded at list
    # time. If for some reason it's gone (Kodi cleaned the temp
    # dir between the dialog and our resolve call), bail with a
    # friendly message.
    local_source = payload.get('local_path')
    src_text = None
    if local_source and os.path.isfile(local_source):
        try:
            with open(local_source, 'r', encoding='utf-8',
                      errors='replace') as f:
                src_text = f.read()
        except (IOError, OSError):
            src_text = None
    if not src_text:
        kodi_utils.notify(
            'הקובץ של הכתוביות המקור לא נמצא. בחר שוב כתובית בשפת מקור '
            'ונסה שוב.')
        return None

    # Sanity: if the source is actually Hebrew (mislabeled),
    # don't translate -- pass through.
    if language_detect.detect(src_text[:8000]) == 'he':
        cache.save_text(translated, src_text)
        return translated

    # Cast metadata (cached per-imdb).
    meta_path = cache.metadata_path(imdb_id) if imdb_id else None
    cast = None
    title = info.get('title') or ''
    year = info.get('year') or ''
    if meta_path:
        cached_meta = cache.load_json(meta_path)
        if cached_meta:
            cast = cached_meta.get('cast') or []
            title = cached_meta.get('title') or title
            year = cached_meta.get('year') or year
    if cast is None:
        try:
            cast = tmdb_helper.fetch_cast(
                imdb_id=imdb_id,
                media_type=('tv' if info.get('is_episode') else 'movie'),
                season=season, episode=episode,
            )
            t2, y2 = tmdb_helper.title_and_year(imdb_id=imdb_id)
            title = title or t2
            year = year or y2
            if meta_path:
                cache.save_json(meta_path, {
                    'cast': cast, 'title': title, 'year': year,
                })
        except Exception as e:
            kodi_utils.log('TMDB lookup failed: {0}'.format(e),
                           level='WARNING')
            cast = []

    # Prompt + chunk + translate via Gemini.
    api_key = kodi_utils.get_setting('api_key', '')
    if not api_key:
        kodi_utils.notify(kodi_utils.localised(33002))
        return None
    model = kodi_utils.get_setting('model', 'gemini-3.1-flash-lite') \
            or 'gemini-3.1-flash-lite'
    temperature = kodi_utils.get_float('temperature', 0.2)
    chunk_lines = kodi_utils.get_int('chunk_lines', 250)

    prompt_template = prompt.build(
        source_lang=source_lang,
        title=title,
        year=year,
        cast=cast,
        is_episode=info.get('is_episode', False),
        tvshow=info.get('tvshow', ''),
        season=season,
        episode=episode,
    )

    blocks = srt.parse_blocks(src_text)
    if not blocks:
        kodi_utils.log('Source SRT had no parseable blocks',
                       level='WARNING')
        return None

    chunks = list(srt.chunk_blocks(blocks, per_chunk=chunk_lines))
    total = len(chunks)
    out_blocks = []

    for i, ch in enumerate(chunks, start=1):
        if progress_cb:
            try:
                progress_cb(i, total)
            except Exception:
                pass
        body = '\n\n'.join(ch)
        full_prompt = prompt_template.replace('{chunk}', body)
        last_err = None
        for attempt in range(2):
            try:
                response = gemini.generate(
                    api_key=api_key,
                    model=model,
                    prompt=full_prompt,
                    temperature=temperature,
                )
                out_blocks.extend(srt.parse_blocks(response))
                last_err = None
                break
            except gemini.QuotaExceeded:
                kodi_utils.notify(kodi_utils.localised(33005))
                return None
            except gemini.InvalidKey as e:
                kodi_utils.notify(kodi_utils.localised(33004,
                    'API key rejected'))
                kodi_utils.log('InvalidKey: {0}'.format(e),
                               level='ERROR')
                return None
            except gemini.GeminiError as e:
                last_err = e
                kodi_utils.log(
                    'Gemini error chunk {0}/{1} attempt {2}: {3}'
                    .format(i, total, attempt + 1, e),
                    level='WARNING')
                time.sleep(2 * (attempt + 1))
                continue
        if last_err is not None:
            kodi_utils.notify(kodi_utils.localised(33008,
                                                   str(last_err)[:80]))
            return None

    final = srt.stitch_blocks(out_blocks)
    cache.save_text(translated, final)
    return translated
