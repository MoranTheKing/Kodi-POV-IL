import xbmcaddon

import os

#########################################################
#         Global Variables - DON'T EDIT!!!              #
#########################################################
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PATH = xbmcaddon.Addon().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'media')
CUSTOM_ART = os.path.join(PATH, 'resources', 'kodi_rd_israel_art')
#########################################################

#########################################################
#        User Edit Variables                            #
#########################################################
ADDONTITLE = '[COLOR yellow]Kodi POV IL Wizard[/COLOR]'
BUILDERNAME = '[COLOR yellow]Kodi POV IL[/COLOR]'
# KODI-RD-IL - Fallback build name. Used by startup.py to populate the
# 'buildname' setting on APK installs where the user never went through
# a wizard-driven Fresh Install (so the setting is empty and the whole
# auto_quick_update path was getting silently no-op'd). Must match the
# name="..." value in build.txt.
BUILDNAME_DEFAULT = 'Kodi POV IL - FENtastic'
# KODI-RD-IL - Fallback build VERSION. Used by startup.py to populate
# the 'buildversion' setting at the same time we populate 'buildname'.
# Without this, the wizard's build_update_check sees an empty
# buildversion and thinks every published version is newer ->
# triggers a destructive full-build-install dialog that wipes the
# user's connected services. Should be kept aligned with the version
# we ship in dist/Kodi-POV-IL-FENtastic-test-*.zip.
BUILDVERSION_DEFAULT = '0.1.45'
EXCLUDES = [ADDON_ID]
# Text File with build info in it. Please read https://github.com/a4k-openproject/plugin.program.openwizard/wiki/Installing-Builds
BUILDFILE = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/build.txt'
# How often you would like it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK = 0
# Text File with apk info in it.  Leave as 'http://' to ignore
APKFILE = 'http://'

#########################################################
# KODI-RD-IL - BUILD SKIN SWITCH
BUILD_SKIN_SWITCH_IMAGE_URL = 'https://github.com/MoranTheKing/Kodi-POV-IL/raw/main/wizard/assets/build_menu_screenshots/pov_il_splash.jpg'
# KODI-RD-IL - AUTO QUICK UPDATES
QUICK_UPDATE_NOTIFICATION_URL = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/notification_files/quick_update.txt'
# The last ten notes, newest first, same format concatenated. Regenerated from
# git at every release by tools/build_recent_updates.py -- so it is the text
# people were actually shown, and it cannot drift from it.
RECENT_UPDATES_URL = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/notification_files/recent_updates.txt'
# KODI-RD-IL - AUTO ANDROID/WINDOWS UPDATE
# WINDOWS SOFTWARE
LATEST_WINDOWS_VERSION_TEXT_FILE = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/kodi_version_auto_update/windows/latest_windows_version.txt'
WINDOWS_DOWNLOAD_URL = 'https://github.com/MoranTheKing/Kodi-POV-IL/releases/latest/download/Kodi-POV-IL-Setup.exe'
WINDOWS_INSTALLATION_PATH = "C:\\Program Files\\Kodi POV IL"
# ANDROID APK
LATEST_APK_VERSION_TEXT_FILE = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/kodi_version_auto_update/apk/latest_apk_version.txt'
APK_DOWNLOAD_URL = 'https://morantheking.github.io/Kodi-POV-IL/downloads/'
# Primary package id our side-by-side APK ships under. Keep it the same
# length as org.xbmc.kodi unless switching to a full from-source Kodi build.
APK_PACKAGE_ID = 'org.xbmc.povi'
# Every package id we have ever shipped. The update check treats all of these
# as "our app" so people on an old org.xbmc.kodirdil build (or the short-lived
# org.moran.kodi / org.mora.kodi rename attempts) still get the update prompt.
APK_PACKAGE_IDS = ['org.xbmc.povi', 'org.xbmc.kodi', 'org.xbmc.kodirdil', 'org.moran.kodi', 'org.mora.kodi']
# Build-only APK/Windows releases that do not require an application reinstall.
# Keep this legacy variable name for compatibility. Startup stays silent and
# the manual menu explains that the installed app can continue to be used.
# The download page still serves the package for new installations.
#
# WHY THIS EXISTS. That dialog fires from startup.py on EVERY start, and its
# "later" button records nothing -- so a release nobody needs is a prompt at
# every boot, forever, until the user reinstalls the whole application. A
# package release is worth that only when the application itself changed. When
# it carries nothing but a newer pre-loaded build zip -- which hydrates a clean
# profile and nothing else, since an existing install gets the same content
# through the ordinary quick update -- an existing user would sit through a
# full reinstall to arrive at what they already have.
#
# NAMED BY TARGET, NOT BY WHO IS INSTALLED, and that is the whole point: this
# says "nobody needs to be moved to .49", not "leave .48 users alone". So it
# expires by itself. The day a package release matters -- a Kodi version bump,
# a signing change, anything in the application -- it simply is not in this
# list, and everyone including the .48 devices is prompted for it as usual,
# with nothing to remember to undo.
NO_AUTO_APP_PROMPT_TARGETS = ['21.3-povil.49']
APK_DOWNLOADER_CODE = ''
APK_DOWNLOADER_CODE_IMAGE_URL = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/kodi_version_auto_update/apk/apk_downloader_code.png'
#########################################################

# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE = ''
YOUTUBEFILE = 'http://'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE = 'http://'
# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE = 'http://'
#########################################################

#########################################################
#        Theming Menu Items                             #
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'https://www.yourhost.com/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONMAINT = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONSPEED = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONAPK = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONADDONS = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONYOUTUBE = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONSAVE = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONTRAKT = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONREAL = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONLOGIN = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONCONTACT = os.path.join(CUSTOM_ART, 'wizard.jpg')
ICONSETTINGS = os.path.join(CUSTOM_ART, 'wizard.jpg')
# Hide the section separators 'Yes' or 'No'
HIDESPACERS = 'No'
# Character used in separator
SPACER = '='

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1 = 'blue'
COLOR2 = 'yellow'
COLOR_LIMEGREEN = 'limegreen'
COLOR_YELLOW = 'yellow'
COLOR_WHITE = 'white'
# Primary menu items   / {0} is the menu item and is required
THEME1 = u'[COLOR {color1}][I][COLOR {color1}][B]Kodi POV IL[/B][/COLOR][COLOR {color2}][COLOR {color1}] - [/I][/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
# Build Names          / {0} is the menu item and is required
THEME2 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
# Alternate items      / {0} is the menu item and is required
THEME3 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
# LIMEGREEN Alternate items      / {0} is the menu item and is required
THEME_LIMEGREEN = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR_LIMEGREEN)
# YELLOW Alternate items      / {0} is the menu item and is required
THEME_YELLOW = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR_YELLOW)
# Current Build Header / {0} is the menu item and is required
THEME4 = u'[COLOR {color1}]בילד נוכחי:[/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
# Current Theme Header / {0} is the menu item and is required
THEME5 = u'[COLOR {color1}]Current Theme:[/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
# KODI_RD_ISRAEL Custom Theme for COLOR_WHITE text usage (window.py - def show_dialog)
THEME6 = u'[COLOR {COLOR_WHITE}]{{}}[/COLOR]'.format(COLOR_WHITE=COLOR_WHITE)

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT = 'Yes'
# You can add \n to do line breaks
CONTACT = 'Thank you for choosing OpenWizard'
# Images used for the contact window.  http:// for default icon and fanart
CONTACTICON = os.path.join(ART, 'qricon.jpg')
CONTACTFANART = 'http://'
#########################################################

#########################################################
#        Auto Update For Those With No Repo             #
#########################################################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE = 'No'
#########################################################

#########################################################
#        Auto Install Repo If Not Installed             #
#########################################################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL = 'No'
# Addon ID for the repository
REPOID = 'spaceholder'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML = 'https://'
# Url to folder zip is located in
REPOZIPURL = 'https://'
#########################################################

#########################################################
#        Notification Window                            #
#########################################################
# Enable Notification screen Yes or No
ENABLE = 'No'
# Url to notification file
NOTIFICATION = 'https://raw.githubusercontent.com/MoranTheKing/Kodi-POV-IL/main/wizard/assets/notification_files/build_first_launch.txt'
# Use either 'Text' or 'Image'
HEADERTYPE = 'Image'
# Font size of header
FONTHEADER = 'Font14'
HEADERMESSAGE = ''
# url to image if using Image 424x180
HEADERIMAGE = os.path.join(CUSTOM_ART, 'kodi_rd_il_icon.png')
# Font for Notification Window
FONTSETTINGS = 'Font13'
# Background for Notification Window
BACKGROUND = 'http://'
#########################################################
